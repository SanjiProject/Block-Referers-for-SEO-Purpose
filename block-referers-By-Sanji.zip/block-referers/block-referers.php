<?php
/*
Plugin Name: Block Unwanted Referers and Anchors with Redirect - By Sanji
Description: Blocks access to the site from specified referers and anchor texts, and redirects them to a target URL with a 301 status. Includes options to disable copy, iframe embedding, and blocking anchors with non-alphanumeric characters. Custom 403 message for blocked referers.
Version: 3.3
Author: Sanji Kenneth
*/

// Function to block and redirect unwanted referers and anchor texts
function bur_block_unwanted_links() {
    if (!get_option('bur_plugin_enabled', 1)) {
        return; // Exit if the plugin is disabled
    }

    $blocked_referers = get_option('bur_blocked_referers', []);
    $blocked_anchors = get_option('bur_blocked_anchors', []);
    $redirect_target = get_option('bur_redirect_target', 'https://your-desired-domain.com');
    $block_non_alphanumeric = get_option('bur_block_non_alphanumeric', 0);

    // Check the referer domain
    if (isset($_SERVER['HTTP_REFERER'])) {
        $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        $referer_host = strtolower(trim($referer_host));

        if (strpos($referer_host, $_SERVER['HTTP_HOST']) !== false) {
            return; // Exit if the referer is from the same site
        }

        foreach ($blocked_referers as $blocked_domain) {
            $blocked_domain = strtolower(trim($blocked_domain));
            if (!empty($blocked_domain) && strpos($referer_host, $blocked_domain) !== false) {
                header("Location: " . $redirect_target, true, 301);
                exit; // Exit after redirecting
            }
        }
    }

    // Check the anchor text in the HTML content of the page
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        ob_start(function($buffer) use ($blocked_anchors, $redirect_target, $block_non_alphanumeric) {
            // Normalize the buffer to lower case for case-insensitive matching
            $buffer_lower = strtolower($buffer);

            // Check for any blocked keywords in anchor texts
            foreach ($blocked_anchors as $blocked_anchor) {
                $blocked_anchor = trim($blocked_anchor);
                // Use preg_quote to safely handle special characters and ensure exact matches
                $pattern = "/\b" . preg_quote($blocked_anchor, '/') . "\b/i";
                if (!empty($blocked_anchor) && preg_match($pattern, $buffer_lower)) {
                    header("Location: " . $redirect_target, true, 301);
                    exit;
                }
            }

            // Check for anchors with non-alphanumeric characters if toggle is enabled
            if ($block_non_alphanumeric && preg_match("/<a[^>]*>([^a-zA-Z0-9\s.,!?\"'()\/&-]*)<\/a>/iu", $buffer)) {
                header("Location: " . $redirect_target, true, 301);
                exit;
            }

            return $buffer;
        });
    }
}
add_action('init', 'bur_block_unwanted_links');

// Prevent iframe embedding
function prevent_iframe_embedding() {
    if (get_option('bur_disable_iframe', 0)) {
        header('X-Frame-Options: SAMEORIGIN');
    }
}
add_action('send_headers', 'prevent_iframe_embedding');

// Disable copy and right-click functionality
function disable_right_click_and_copy() {
    if (get_option('bur_disable_copy', 0)) {
        ?>
        <script type="text/javascript">
            // Disable right-click
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });

            // Disable text selection and copying
            document.addEventListener('keydown', function(e) {
                // Disable Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I (View source, copy, dev tools)
                if (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's') || 
                    (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                    e.preventDefault();
                }
            });

            // Disable text selection
            document.addEventListener('selectstart', function(e) {
                e.preventDefault();
            });
        </script>

        <style type="text/css">
            /* Disable text selection on the page */
            body {
                -webkit-user-select: none; /* Safari */
                -moz-user-select: none;    /* Firefox */
                -ms-user-select: none;     /* Internet Explorer/Edge */
                user-select: none;         /* Standard syntax */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'disable_right_click_and_copy');

// Function to block specific sites with 403 status and custom message
function bur_block_specific_referers() {
    $blocked_403_referers = get_option('bur_blocked_403_referers', []);
    $custom_403_message = get_option('bur_custom_403_message', 'Access denied. You are not allowed to access this site.');

    if (isset($_SERVER['HTTP_REFERER'])) {
        foreach ($blocked_403_referers as $blocked_403_domain) {
            if (strpos($_SERVER['HTTP_REFERER'], $blocked_403_domain) !== false) {
                header('HTTP/1.0 403 Forbidden');
                echo '<h1>403 Forbidden</h1>';
                echo '<p>' . esc_html($custom_403_message) . '</p>';
                exit; // Stop further execution
            }
        }
    }
}
add_action('init', 'bur_block_specific_referers');

// Admin menu creation function
function bur_block_referers_menu() {
    add_menu_page(
        'Blocked Referers and Anchors',
        'Blocked Referers',
        'manage_options',
        'blocked-referers',
        'bur_blocked_referers_page',
        'dashicons-lock',
        100
    );
}
add_action('admin_menu', 'bur_block_referers_menu');

// Admin page to manage blocked referers, anchors, and settings
function bur_blocked_referers_page() {
    if (isset($_POST['submit_toggle'])) {
        update_option('bur_plugin_enabled', isset($_POST['plugin_enabled']) ? 1 : 0);
        update_option('bur_block_non_alphanumeric', isset($_POST['block_non_alphanumeric']) ? 1 : 0);
        update_option('bur_disable_iframe', isset($_POST['disable_iframe']) ? 1 : 0);
        update_option('bur_disable_copy', isset($_POST['disable_copy']) ? 1 : 0);
        update_option('bur_custom_403_message', sanitize_text_field($_POST['custom_403_message']));
        echo '<div class="notice notice-success"><p>Plugin status and settings updated!</p></div>';
    }

    if (isset($_POST['submit_referers'])) {
        $blocked_referers = array_map('sanitize_text_field', explode(',', $_POST['referers']));
        $blocked_anchors = array_map('sanitize_text_field', explode(',', $_POST['anchors']));
        update_option('bur_blocked_referers', $blocked_referers);
        update_option('bur_blocked_anchors', $blocked_anchors);
        update_option('bur_redirect_target', sanitize_text_field($_POST['redirect_target']));
        echo '<div class="notice notice-success"><p>Blocked referers, anchors, and redirect target updated!</p></div>';
    }

    if (isset($_POST['submit_403_referers'])) {
        $blocked_403_referers = array_map('sanitize_text_field', explode(',', $_POST['403_referers']));
        update_option('bur_blocked_403_referers', $blocked_403_referers);
        echo '<div class="notice notice-success"><p>403 blocked referers updated!</p></div>';
    }

    $current_referers = get_option('bur_blocked_referers', []);
    $current_anchors = get_option('bur_blocked_anchors', []);
    $redirect_target = get_option('bur_redirect_target', 'https://your-desired-domain.com');
    $plugin_enabled = get_option('bur_plugin_enabled', 1);
    $block_non_alphanumeric = get_option('bur_block_non_alphanumeric', 0);
    $disable_iframe = get_option('bur_disable_iframe', 0);
    $disable_copy = get_option('bur_disable_copy', 0);
    $blocked_403_referers = get_option('bur_blocked_403_referers', []);
    $custom_403_message = get_option('bur_custom_403_message', 'Access denied. You are not allowed to access this site.');
    ?>
    <div class="wrap bur-admin-page">
        <h1>Blocked Referers and Anchors</h1>

        <div class="flex-container">
            <div class="card">
                <div class="card-body">
                    <h2>Plugin Status and Settings</h2>
                    <form method="post" action="">
                        <label>
                            <input type="checkbox" name="plugin_enabled" value="1" <?php checked($plugin_enabled, 1); ?> />
                            Enable Plugin
                        </label><br>
                        <label>
                            <input type="checkbox" name="block_non_alphanumeric" value="1" <?php checked($block_non_alphanumeric, 1); ?> />
                            Block Non-Alphanumeric Anchor Texts
                        </label><br>
                        <label>
                            <input type="checkbox" name="disable_iframe" value="1" <?php checked($disable_iframe, 1); ?> />
                            Disable Iframe Embedding
                        </label><br>
                        <label>
                            <input type="checkbox" name="disable_copy" value="1" <?php checked($disable_copy, 1); ?> />
                            Disable Copy/Right-click
                        </label><br>
                        
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h2>Redirect Referers and Anchors</h2>
                    <form method="post" action="">
                        <label>Blocked Referers (comma-separated):</label><br>
                        <textarea name="referers" rows="5" cols="50"><?php echo esc_textarea(implode(',', $current_referers)); ?></textarea><br>
                        <label>Blocked Anchors (comma-separated):</label><br>
                        <textarea name="anchors" rows="5" cols="50"><?php echo esc_textarea(implode(',', $current_anchors)); ?></textarea><br>
                        <label>Redirect Target URL:</label><br>
                        <input type="text" name="redirect_target" size="50" value="<?php echo esc_attr($redirect_target); ?>" /><br>
                        <input type="submit" name="submit_referers" class="button button-primary" value="Save" />
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h2>Block Referers with 403</h2>
                    <form method="post" action="">
                        <label>Referers to Block with 403 (comma-separated):</label><br>
                        <textarea name="403_referers" rows="5" cols="50"><?php echo esc_textarea(implode(',', $blocked_403_referers)); ?></textarea><br>
                        <input type="submit" name="submit_403_referers" class="button button-primary" value="Save" /><br><br>
                        <label>Custom 403 Message:</label><br>
                        <textarea name="custom_403_message" rows="3" cols="50"><?php echo esc_textarea($custom_403_message); ?></textarea><br>
                        <input type="submit" name="submit_toggle" class="button button-primary" value="Save" />
                    </form>
                </div>
            </div>
        </div>
    </div>
    <style>
        .flex-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .card {
            background: #fff;
            border: 1px solid #ccc;
            box-shadow: 0 1px 3px rgba(0,0,0,.1);
            padding: 20px;
            flex: 1 1 30%;
            max-width: 30%;
        }
        .card-body {
            display: flex;
            flex-direction: column;
        }
    </style>
    <?php
}
