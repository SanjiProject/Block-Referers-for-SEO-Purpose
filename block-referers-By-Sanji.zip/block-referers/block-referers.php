<?php
/*
Plugin Name: Block Unwanted Referers with Redirect - By Sanji
Description: Blocks access to the site from specified referers, and redirects them to a target URL with a 301 status. Includes options to disable copy and iframe embedding.
Version: 3.1
Author: Sanji Kenneth
*/

// Function to block and redirect unwanted referers
function bur_block_unwanted_links() {
    if (!get_option('bur_plugin_enabled', 1)) {
        return; // Exit if the plugin is disabled
    }

    $blocked_referers = get_option('bur_blocked_referers', []);
    $redirect_target = get_option('bur_redirect_target', 'https://your-desired-domain.com');

    // Check the referer domain
    if (isset($_SERVER['HTTP_REFERER'])) {
        $referer_host = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        $referer_host = strtolower(trim($referer_host));

        if (strpos($referer_host, $_SERVER['HTTP_HOST']) !== false) {
            return; // Exit if the referer is from the same site
        }

        foreach ($blocked_referers as $blocked_domain) {
            $blocked_domain = strtolower(trim($blocked_domain));
            if (!empty($blocked_domain) && strpos($referer_host, $blocked_domain) !== false) {
                header("Location: " . $redirect_target, true, 301);
                exit; // Exit after redirecting
            }
        }
    }
}
add_action('init', 'bur_block_unwanted_links');

// Prevent iframe embedding
function prevent_iframe_embedding() {
    if (get_option('bur_disable_iframe', 0)) {
        header('X-Frame-Options: SAMEORIGIN');
    }
}
add_action('send_headers', 'prevent_iframe_embedding');

// Disable copy and right-click functionality
function disable_right_click_and_copy() {
    if (get_option('bur_disable_copy', 0)) {
        ?>
        <script type="text/javascript">
            // Disable right-click
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });

            // Disable text selection and copying
            document.addEventListener('keydown', function(e) {
                if (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's') || 
                    (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                    e.preventDefault();
                }
            });

            // Disable text selection
            document.addEventListener('selectstart', function(e) {
                e.preventDefault();
            });
        </script>

        <style type="text/css">
            /* Disable text selection on the page */
            body {
                -webkit-user-select: none; /* Safari */
                -moz-user-select: none;    /* Firefox */
                -ms-user-select: none;     /* Internet Explorer/Edge */
                user-select: none;         /* Standard syntax */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'disable_right_click_and_copy');

// Admin menu creation function
function bur_block_referers_menu() {
    add_menu_page(
        'Blocked Referers',
        'Blocked Referers',
        'manage_options',
        'blocked-referers',
        'bur_blocked_referers_page',
        'dashicons-lock',
        100
    );
}
add_action('admin_menu', 'bur_block_referers_menu');

// Admin page to manage blocked referers and settings
function bur_blocked_referers_page() {
    if (isset($_POST['submit_toggle'])) {
        update_option('bur_plugin_enabled', isset($_POST['plugin_enabled']) ? 1 : 0);
        update_option('bur_disable_iframe', isset($_POST['disable_iframe']) ? 1 : 0);
        update_option('bur_disable_copy', isset($_POST['disable_copy']) ? 1 : 0);
        echo '<div class="notice notice-success"><p>Plugin status updated!</p></div>';
    }

    if (isset($_POST['submit_referers'])) {
        $blocked_referers = array_map('sanitize_text_field', explode("\n", trim($_POST['referers'])));
        update_option('bur_blocked_referers', $blocked_referers);
        update_option('bur_redirect_target', sanitize_text_field($_POST['redirect_target']));
        echo '<div class="notice notice-success"><p>Blocked referers and redirect target updated!</p></div>';
    }

    $current_referers = get_option('bur_blocked_referers', []);
    $redirect_target = get_option('bur_redirect_target', 'https://your-desired-domain.com');
    $plugin_enabled = get_option('bur_plugin_enabled', 1);
    $disable_iframe = get_option('bur_disable_iframe', 0);
    $disable_copy = get_option('bur_disable_copy', 0);
    ?>
    <div class="wrap bur-admin-page">
        <h1>Blocked Referers</h1>

        <div class="flex-container">
            <div class="card">
                <div class="card-body">
                    <h2>Plugin Status</h2>
                    <form method="post" action="">
                        <label>
                            <input type="checkbox" name="plugin_enabled" value="1" <?php checked($plugin_enabled, 1); ?> />
                            Enable Plugin
                        </label><br>
                        <label>
                            <input type="checkbox" name="disable_iframe" value="1" <?php checked($disable_iframe, 1); ?> />
                            Prevent Iframe Embedding
                        </label><br>
                        <label>
                            <input type="checkbox" name="disable_copy" value="1" <?php checked($disable_copy, 1); ?> />
                            Disable Right-Click and Copy
                        </label><br><br>
                        <input type="submit" name="submit_toggle" class="button button-primary" value="Update Plugin Status" />
                    </form>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h2>Manage Blocked Referers</h2>
                    <form method="post" action="">
                        <label for="referers">Enter domains to block (one per line):</label>
                        <textarea id="referers" name="referers" rows="10" class="form-control"><?php echo esc_textarea(implode("\n", $current_referers)); ?></textarea>
                        <br><br>
                        <label for="redirect_target">Redirect Target URL:</label>
                        <input type="text" id="redirect_target" name="redirect_target" value="<?php echo esc_attr($redirect_target); ?>" class="form-control" />
                        <br><br>
                        <input type="submit" name="submit_referers" class="button button-primary" value="Update Blocked Referers" />
                    </form>
                </div>
            </div>
        </div>
    </div>
<style>
    .flex-container {
        display: flex;
        flex-direction: column; /* Change this to column for vertical stacking */
        align-items: stretch; /* Ensure cards take full width */
    }
    .card {
        margin-bottom: 20px; /* Add some space between the cards */
        background: #f9f9f9;
        border: 1px solid #ddd;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .card-body h2 {
        margin-top: 0;
    }
    .form-control {
        width: 100%;
        padding: 8px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 3px;
    }
</style>

    <?php
}
