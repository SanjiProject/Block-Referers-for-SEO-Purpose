<?php
/*
Plugin Name: Block Unwanted Referers and Anchors - By Sanji
Description: Blocks access to the site from specified referers and anchor texts. Includes options to disable copy, iframe embedding, block anchors without alphanumeric characters, and block link equity from incoming referers.
Version: 1.8
Author: Sanji Kenneth
*/

// Function to block unwanted referers and anchors, and block link equity from incoming referers
function bur_block_unwanted_referers_and_anchors() {
    // Retrieve blocked referers and anchors from the database
    $blocked_referers = get_option('bur_blocked_referers', []);
    $blocked_anchors = get_option('bur_blocked_anchors', []);
    $block_non_alphanumeric_anchors = get_option('bur_block_non_alphanumeric_anchors', 0);

    // Check if the HTTP_REFERER is set
    if (isset($_SERVER['HTTP_REFERER'])) {
        $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
        
        // Check if the referer is in the blocked list
        if (in_array($referer, $blocked_referers)) {
            error_log("Blocked referer: " . $_SERVER['HTTP_REFERER'], 0);
            // Block link equity by adding rel="nofollow"
            add_action('wp_head', function() {
                echo '<meta name="robots" content="noindex, nofollow">';
            });
            wp_die('403 Forbidden', 'Forbidden', array('response' => 403));
        }
        
        // Check for blocked anchors
        foreach ($blocked_anchors as $anchor) {
            if (strpos($_SERVER['HTTP_REFERER'], $anchor) !== false) {
                error_log("Blocked anchor text in referer: " . $_SERVER['HTTP_REFERER'], 0);
                // Block link equity by adding rel="nofollow"
                add_action('wp_head', function() {
                    echo '<meta name="robots" content="noindex, nofollow">';
                });
                wp_die('403 Forbidden', 'Forbidden', array('response' => 403));
            }
        }

        // Check if blocking of non-alphanumeric anchors is enabled
        if ($block_non_alphanumeric_anchors) {
            $path = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH);
            if (!preg_match('/[a-zA-Z0-9]/', $path)) {
                error_log("Blocked non-alphanumeric anchor in referer: " . $_SERVER['HTTP_REFERER'], 0);
                // Block link equity by adding rel="nofollow"
                add_action('wp_head', function() {
                    echo '<meta name="robots" content="noindex, nofollow">';
                });
                wp_die('403 Forbidden', 'Forbidden', array('response' => 403));
            }
        }
    }
}

// Hook into 'init'
add_action('init', 'bur_block_unwanted_referers_and_anchors');

// Create admin menu for the plugin
function bur_block_referers_menu() {
    add_menu_page(
        'Blocked Referers and Anchors',
        'Blocked Referers',
        'manage_options',
        'blocked-referers',
        'bur_blocked_referers_page',
        'dashicons-lock', // Icon for the menu
        100 // Position
    );
}
add_action('admin_menu', 'bur_block_referers_menu');

// Admin page content
function bur_blocked_referers_page() {
    // Handle form submission for blocked referers
    if (isset($_POST['submit_referers'])) {
        $blocked_referers = array_map('sanitize_text_field', explode(',', $_POST['referers']));
        update_option('bur_blocked_referers', $blocked_referers);
        echo '<div class="updated notice"><p>Blocked referers updated!</p></div>';
    }

    // Handle form submission for blocked anchors
    if (isset($_POST['submit_anchors'])) {
        $blocked_anchors = array_map('sanitize_text_field', explode(',', $_POST['anchors']));
        update_option('bur_blocked_anchors', $blocked_anchors);
        echo '<div class="updated notice"><p>Blocked anchors updated!</p></div>';
    }

    // Handle form submission for disabling copy, iframe embedding, and non-alphanumeric anchors
    if (isset($_POST['submit_settings'])) {
        update_option('bur_disable_copy', isset($_POST['disable_copy']) ? 1 : 0);
        update_option('bur_disable_iframe', isset($_POST['disable_iframe']) ? 1 : 0);
        update_option('bur_block_non_alphanumeric_anchors', isset($_POST['block_non_alphanumeric_anchors']) ? 1 : 0);
        echo '<div class="updated notice"><p>Settings updated!</p></div>';
    }

    // Get the current blocked referers, anchors, and settings
    $current_referers = get_option('bur_blocked_referers', []);
    $current_anchors = get_option('bur_blocked_anchors', []);
    $disable_copy = get_option('bur_disable_copy', 0);
    $disable_iframe = get_option('bur_disable_iframe', 0);
    $block_non_alphanumeric_anchors = get_option('bur_block_non_alphanumeric_anchors', 0);
    ?>
    <div class="wrap">
        <h1>Blocked Referers and Anchors</h1>

        <h2 class="title">Manage Blocked Referers</h2>
        <form method="post" action="" class="bur-form">
            <label for="referers">Enter domains to block (comma-separated):</label>
            <input type="text" id="referers" name="referers" value="<?php echo esc_attr(implode(',', $current_referers)); ?>" class="regular-text" />
            <input type="submit" name="submit_referers" class="button button-primary" value="Update Blocked Referers" />
        </form>

        <h2 class="title">Manage Blocked Anchors</h2>
        <form method="post" action="" class="bur-form">
            <label for="anchors">Enter anchor texts to block (comma-separated):</label>
            <input type="text" id="anchors" name="anchors" value="<?php echo esc_attr(implode(',', $current_anchors)); ?>" class="regular-text" />
            <input type="submit" name="submit_anchors" class="button button-primary" value="Update Blocked Anchors" />
        </form>

        <h2 class="title">Settings</h2>
        <form method="post" action="" class="bur-form">
            <label>
                <input type="checkbox" name="disable_copy" value="1" <?php checked($disable_copy, 1); ?> />
                Disable Right Click and Copy
            </label><br>
            <label>
                <input type="checkbox" name="disable_iframe" value="1" <?php checked($disable_iframe, 1); ?> />
                Disable Iframe Embedding
            </label><br>
            <label>
                <input type="checkbox" name="block_non_alphanumeric_anchors" value="1" <?php checked($block_non_alphanumeric_anchors, 1); ?> />
                Block Anchors Without Alphanumeric Characters
            </label><br><br>
            <input type="submit" name="submit_settings" class="button button-primary" value="Update Settings" />
        </form>

        <h3>Current Blocked Referers:</h3>
        <ul class="bur-list">
            <?php foreach ($current_referers as $referer) : ?>
                <li><?php echo esc_html($referer); ?></li>
            <?php endforeach; ?>
        </ul>

        <h3>Current Blocked Anchors:</h3>
        <ul class="bur-list">
            <?php foreach ($current_anchors as $anchor) : ?>
                <li><?php echo esc_html($anchor); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <style>
        .bur-form {
            margin-bottom: 20px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #f9f9f9;
        }

        .bur-form label {
            display: block;
            margin-bottom: 5px;
        }

        .bur-list {
            list-style: disc;
            padding-left: 20px;
        }

        .bur-list li {
            margin-bottom: 5px;
        }

        .title {
            margin-top: 20px;
            margin-bottom: 10px;
            color: #0073aa;
        }
    </style>
    <?php
}

// Block site from being embedded in iframes
function prevent_iframe_embedding() {
    if (get_option('bur_disable_iframe', 0)) {
        header('X-Frame-Options: SAMEORIGIN');
    }
}
add_action('send_headers', 'prevent_iframe_embedding');

// Disable copy and right-click functionality
function disable_right_click_and_copy() {
    if (get_option('bur_disable_copy', 0)) {
        ?>
        <script type="text/javascript">
            // Disable right-click
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });

            // Disable text selection and copying
            document.addEventListener('keydown', function(e) {
                // Disable Ctrl+C, Ctrl+U, Ctrl+S, Ctrl+Shift+I (View source, copy, dev tools)
                if (e.ctrlKey && (e.key === 'c' || e.key === 'u' || e.key === 's') || 
                    (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                    e.preventDefault();
                }
            });

            // Disable text selection
            document.addEventListener('selectstart', function(e) {
                e.preventDefault();
            });
        </script>

        <style type="text/css">
            /* Disable text selection on the page */
            body {
                -webkit-user-select: none; /* Safari */
                -moz-user-select: none;    /* Firefox */
                -ms-user-select: none;     /* Internet Explorer/Edge */
                user-select: none;         /* Standard syntax */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'disable_right_click_and_copy');
?>
