<?php
/*
Plugin Name: Block Unwanted Referers and Anchors - By Sanji
Description: Blocks access to the site from specified referers and anchor texts. Includes options to disable copy, iframe embedding, block anchors without alphanumeric characters, and block link equity from incoming referers.
Version: 1.9
Author: Sanji Kenneth
*/

function bur_block_unwanted_referers_and_anchors() {
    $blocked_referers = get_option('bur_blocked_referers', []);
    $blocked_anchors = get_option('bur_blocked_anchors', []);
    $redirect_url = get_option('bur_redirect_url', 'https://yourredirecturl.com');
    $block_non_alphanumeric_anchors = get_option('bur_block_non_alphanumeric_anchors', 0);
    $site_url = parse_url(home_url(), PHP_URL_HOST);

    if (isset($_SERVER['HTTP_REFERER'])) {
        $referer = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);

        if ($referer === $site_url) {
            return; // Allow access if the referer is from the same site
        }

        if (in_array($referer, $blocked_referers)) {
            wp_redirect($redirect_url, 301); // 301 redirect
            exit;
        }

        foreach ($blocked_anchors as $anchor) {
            if (strpos($_SERVER['HTTP_REFERER'], $anchor) !== false) {
                wp_redirect($redirect_url, 301); // 301 redirect
                exit;
            }
        }

        if ($block_non_alphanumeric_anchors) {
            $path = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_PATH);
            if (!preg_match('/[a-zA-Z0-9]/', $path)) {
                wp_redirect($redirect_url, 301); // 301 redirect
                exit;
            }
        }
    }
}

add_action('init', 'bur_block_unwanted_referers_and_anchors');

function bur_block_referers_menu() {
    add_menu_page(
        'Blocked Referers and Anchors',
        'Blocked Referers',
        'manage_options',
        'blocked-referers',
        'bur_blocked_referers_page',
        'dashicons-shield',
        100
    );
}
add_action('admin_menu', 'bur_block_referers_menu');

function bur_blocked_referers_page() {
    if (isset($_POST['submit_referers'])) {
        $blocked_referers = array_map('sanitize_text_field', explode(',', $_POST['referers']));
        if (empty($blocked_referers[0])) {
            wp_die('Blocked referers cannot be empty.', 'Error', array('response' => 403));
        }
        update_option('bur_blocked_referers', $blocked_referers);
        echo '<div class="notice notice-success is-dismissible"><p>Blocked referers updated!</p></div>';
    }

    if (isset($_POST['submit_anchors'])) {
        $blocked_anchors = array_map('sanitize_text_field', explode(',', $_POST['anchors']));
        if (empty($blocked_anchors[0])) {
            wp_die('Blocked anchors cannot be empty.', 'Error', array('response' => 403));
        }
        update_option('bur_blocked_anchors', $blocked_anchors);
        echo '<div class="notice notice-success is-dismissible"><p>Blocked anchors updated!</p></div>';
    }

    if (isset($_POST['submit_redirect_url'])) {
        $redirect_url = sanitize_text_field($_POST['redirect_url']);
        if (empty($redirect_url)) {
            wp_die('Redirect URL cannot be empty.', 'Error', array('response' => 403));
        }
        update_option('bur_redirect_url', $redirect_url);
        echo '<div class="notice notice-success is-dismissible"><p>Redirect URL updated!</p></div>';
    }

    if (isset($_POST['submit_settings'])) {
        update_option('bur_disable_copy', isset($_POST['disable_copy']) ? 1 : 0);
        update_option('bur_disable_iframe', isset($_POST['disable_iframe']) ? 1 : 0);
        update_option('bur_block_non_alphanumeric_anchors', isset($_POST['block_non_alphanumeric_anchors']) ? 1 : 0);
        echo '<div class="notice notice-success is-dismissible"><p>Settings updated!</p></div>';
    }

    $current_referers = get_option('bur_blocked_referers', []);
    $current_anchors = get_option('bur_blocked_anchors', []);
    $redirect_url = get_option('bur_redirect_url', 'https://yourredirecturl.com');
    $disable_copy = get_option('bur_disable_copy', 0);
    $disable_iframe = get_option('bur_disable_iframe', 0);
    $block_non_alphanumeric_anchors = get_option('bur_block_non_alphanumeric_anchors', 0);
    ?>
    <div class="wrap">
        <h1>Blocked Referers and Anchors</h1>

        <!-- Top Section: 1-2-3-4 Layout -->
        <div class="bur-grid-top">
            <div class="card bur-card">
                <h2 class="title">Manage Blocked Referers</h2>
                <form method="post" action="">
                    <label for="referers">Enter domains to block (comma-separated):</label>
                    <input type="text" id="referers" name="referers" value="<?php echo esc_attr(implode(',', $current_referers)); ?>" class="regular-text" />
                    <input type="submit" name="submit_referers" class="button button-primary" value="Update Blocked Referers" />
                </form>
            </div>

            <div class="card bur-card">
                <h2 class="title">Manage Blocked Anchors</h2>
                <form method="post" action="">
                    <label for="anchors">Enter anchor texts to block (comma-separated):</label>
                    <input type="text" id="anchors" name="anchors" value="<?php echo esc_attr(implode(',', $current_anchors)); ?>" class="regular-text" />
                    <input type="submit" name="submit_anchors" class="button button-primary" value="Update Blocked Anchors" />
                </form>
            </div>

            <div class="card bur-card">
                <h2 class="title">Redirect URL</h2>
                <form method="post" action="">
                    <label for="redirect_url">Enter Redirect URL:</label>
                    <input type="text" id="redirect_url" name="redirect_url" value="<?php echo esc_attr($redirect_url); ?>" class="regular-text" />
                    <input type="submit" name="submit_redirect_url" class="button button-primary" value="Update Redirect URL" />
                </form>
            </div>

            <div class="card bur-card">
                <h2 class="title">Additional Settings</h2>
                <form method="post" action="">
                    <label>
                        <input type="checkbox" name="disable_copy" value="1" <?php checked($disable_copy, 1); ?> />
                        Disable Right Click and Copy
                    </label><br>
                    <label>
                        <input type="checkbox" name="disable_iframe" value="1" <?php checked($disable_iframe, 1); ?> />
                        Disable Iframe Embedding
                    </label><br>
                    <label>
                        <input type="checkbox" name="block_non_alphanumeric_anchors" value="1" <?php checked($block_non_alphanumeric_anchors, 1); ?> />
                        Block Anchors Without Alphanumeric Characters
                    </label><br><br>
                    <input type="submit" name="submit_settings" class="button button-primary" value="Update Settings" />
                </form>
            </div>
        </div>

        <!-- Bottom Section: 1-2 Layout -->
        <div class="bur-grid-bottom">
            <div class="card bur-card">
                <h3>Current Blocked Referers:</h3>
                <ul class="bur-list">
                    <?php if (!empty($current_referers)) : ?>
                        <?php foreach ($current_referers as $referer) : ?>
                            <li><?php echo esc_html($referer); ?></li>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <li>No referers blocked yet.</li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="card bur-card">
                <h3>Current Blocked Anchors:</h3>
                <ul class="bur-list">
                    <?php if (!empty($current_anchors)) : ?>
                        <?php foreach ($current_anchors as $anchor) : ?>
                            <li><?php echo esc_html($anchor); ?></li>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <li>No anchors blocked yet.</li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <style>
        .bur-grid-top {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .bur-grid-bottom {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 20px;
        }
        .bur-card {
            background: #fff;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            flex: 1 1 300px;
        }
        .bur-list {
            list-style-type: none;
            padding: 0;
        }
        .bur-list li {
            padding: 5px 0;
        }
        .bur-card .title {
            margin-top: 0;
        }
    </style>
    <?php
}
